﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using BabelSimpleMvcApi.Models;

namespace BabelSimpleMvcApi.Api
{
    public class AuthorsController : ApiController
    {
        private BabelEntities1 db = new BabelEntities1();

        // GET: api/Authors
        public IQueryable<BabelAuthor> GetAuthors()
        {
            return db.BabelAuthors.Where(r => r.IsListed == true);          // Return only listed authors
        }

        // GET: api/Authors/5
        [ResponseType(typeof(BabelAuthor))]
        public IHttpActionResult GetAuthor(int id)
        {
            BabelAuthor babelAuthor = db.BabelAuthors.Find(id);

            if (babelAuthor == null)
            {
                return NotFound();
            }
            else if (!(babelAuthor.IsDisplay ?? false))                 // Return only authors with displayable profiles
            {
                return NotFound();
            }

            return Ok(babelAuthor);
        }
       

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BabelAuthorExists(int id)
        {
            return db.BabelAuthors.Count(e => e.AuthorId == id) > 0;
        }
    }
}