﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using BabelSimpleMvcApi.Models;

namespace BabelSimpleMvcApi.Api
{
    public class PublicationsController : ApiController
    {
        private BabelEntities1 db = new BabelEntities1();

        // GET: api/Publications
        public IQueryable<Publication> GetPublications()
        {
            return db.Publications;
        }

        // GET: api/Publications/5
        [ResponseType(typeof(Publication))]
        public IHttpActionResult GetPublication(int id)
        {
            Publication publication = (Publication)(db.Publications.Where(r => r.PublicationId == id));
            if (publication == null)
            {
                return NotFound();
            }

            return Ok(publication);
        }

        // GET: api/Publications/{keyname}/5
        public IQueryable<Publication> GetPublications(string keyname, int id)
        {
            switch (keyname)
            {
                case "Author":
                    return db.Publications.Where(r => r.AuthorId == id);        //Publications by Author
                case "Category":
                    return db.Publications.Where(r => r.CategoryId == id);      //Publications by Category
                default:
                    return db.Publications;
            }
            
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PublicationExists(int id)
        {
            return db.Publications.Count(e => e.PublicationId == id) > 0;
        }
    }
}